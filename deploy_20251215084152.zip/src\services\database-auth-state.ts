import { AuthenticationState, AuthenticationCreds, SignalDataTypeMap } from '@whiskeysockets/baileys';
import { proto } from '@whiskeysockets/baileys';
import db from '../config/database';
import logger from '../utils/logger';

export class DatabaseAuthState {
  private sessionId: string;
  private stateCache: { creds?: AuthenticationCreds } = {};

  constructor(sessionId: string) {
    this.sessionId = sessionId;
  }

  private async getKey(key: string): Promise<any> {
    try {
      const row = await db('auth_state')
        .where({ session_id: this.sessionId, key })
        .first();
      
      if (!row) return null;
      
      return JSON.parse(row.value);
    } catch (error) {
      logger.error(`DB auth getKey error: sessionId=${this.sessionId} key=${key}`, error);
      return null;
    }
  }

  private async setKey(key: string, value: any): Promise<void> {
    try {
      const valueStr = JSON.stringify(value);
      
      await db('auth_state')
        .insert({
          session_id: this.sessionId,
          key,
          value: valueStr,
          updated_at: db.fn.now()
        })
        .onConflict(['session_id', 'key'])
        .merge({
          value: valueStr,
          updated_at: db.fn.now()
        });
    } catch (error) {
      logger.error(`DB auth setKey error: sessionId=${this.sessionId} key=${key}`, error);
      throw error;
    }
  }

  private async removeKey(key: string): Promise<void> {
    try {
      await db('auth_state')
        .where({ session_id: this.sessionId, key })
        .delete();
    } catch (error) {
      logger.error(`DB auth removeKey error: sessionId=${this.sessionId} key=${key}`, error);
    }
  }

  async getAuthState(): Promise<{ state: AuthenticationState; saveCreds: () => Promise<void> }> {
    const creds: AuthenticationCreds | null = await this.getKey('creds');
    this.stateCache.creds = creds || undefined;

    const self = this;

    return {
      state: {
        creds: this.stateCache.creds as AuthenticationCreds,
        keys: {
          get: async <T extends keyof SignalDataTypeMap>(type: T, ids: string[]): Promise<{ [id: string]: SignalDataTypeMap[T] }> => {
            const data: { [id: string]: SignalDataTypeMap[T] } = {};
            
            for (const id of ids) {
              const key = `${type}-${id}`;
              const value = await self.getKey(key);
              if (value) {
                data[id] = value as SignalDataTypeMap[T];
              }
            }
            
            return data;
          },
          set: async (data: any) => {
            const promises: Promise<void>[] = [];
            
            for (const category in data) {
              for (const id in data[category]) {
                const key = `${category}-${id}`;
                const value = data[category][id];
                
                if (value === null) {
                  promises.push(self.removeKey(key));
                } else {
                  promises.push(self.setKey(key, value));
                }
              }
            }
            
            await Promise.all(promises);
          }
        }
      },
      saveCreds: async () => {
        if (self.stateCache.creds) {
          await self.setKey('creds', self.stateCache.creds);
        }
      }
    };
  }

  async clearAuthState(): Promise<void> {
    try {
      await db('auth_state')
        .where({ session_id: this.sessionId })
        .delete();
      
      logger.info(`Cleared auth state for session: ${this.sessionId}`);
    } catch (error) {
      logger.error(`Clear auth state error: sessionId=${this.sessionId}`, error);
      throw error;
    }
  }
}
