import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../services/api';

type ApiKey = { key: string; sessionId: string; name: string };
type Session = { sessionId: string; name: string; status: string; phoneNumber?: string };

const STORAGE_KEY = 'sak.onboarding';

export default function Onboarding() {
  useAuth();
  const [step, setStep] = useState(1);
  const [apiKey, setApiKey] = useState<ApiKey | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [sendingTest, setSendingTest] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const next = () => setStep((s) => Math.min(s + 1, 6));
  const prev = () => setStep((s) => Math.max(s - 1, 1));

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);

      if (parsed?.apiKey?.key && parsed?.apiKey?.sessionId && parsed?.apiKey?.name) {
        setApiKey(parsed.apiKey);
      }
      if (parsed?.session?.sessionId && parsed?.session?.name && parsed?.session?.status) {
        setSession(parsed.session);
      }
      if (typeof parsed?.webhookUrl === 'string') {
        setWebhookUrl(parsed.webhookUrl);
      }
      if (typeof parsed?.step === 'number') {
        setStep(Math.max(1, Math.min(6, parsed.step)));
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ step, apiKey, session, webhookUrl })
      );
    } catch {
      // ignore
    }
  }, [step, apiKey, session, webhookUrl]);

  async function createApiKey() {
    setErrorMsg(null);
    try {
      const res = await api.post('/sessions', { name: 'primary-number' });
      const data = res.data.data || res.data;

      const sessionId = data.sessionId || data.session_id || data.id;
      const key = data.apiKey || data.api_key;
      const name = data.name || 'primary-number';
      const status = data.status || 'pending';

      if (!sessionId || !key) {
        setErrorMsg('Session created but API key was missing in response.');
        return;
      }

      setApiKey({ key, sessionId, name });
      setSession({ sessionId, name, status });
      next();
    } catch (err: any) {
      const status = err?.response?.status;
      const code = err?.response?.data?.error?.code;

      // Free plan users hit this if they refresh and try to create another session.
      if (status === 403 && code === 'SESSION_LIMIT_REACHED') {
        if (apiKey?.key && session?.sessionId) {
          setErrorMsg('Session limit reached, reusing your existing session. Click Continue.');
          return;
        }
        setErrorMsg('Session limit reached (Free plan allows 1 session). Go to Sessions and delete the old session, or upgrade your plan.');
        return;
      }

      setErrorMsg(err?.response?.data?.error?.message || 'Failed to create session.');
      return;
    }
  }

  async function createSession() {
    if (!session) {
      await createApiKey();
      return;
    }

    const res = await api.get(`/sessions/${session.sessionId}/status`);
    const data = res.data.data || res.data;
    const connected = data.connected ?? data.status === 'connected';

    setSession({
      ...session,
      status: connected ? 'connected' : session.status,
      phoneNumber: data.phoneNumber || session.phoneNumber
    });
    next();
  }

  async function fetchQr() {
    if (!session || !apiKey) return;
    try {
      const res = await api.get(`/sessions/${session.sessionId}/qr`);
      const qrCode =
        res.data.data?.qrCode ||
        res.data.data?.qr_code ||
        res.data.qrCode ||
        res.data.qr_code ||
        null;
      setQr(qrCode || null);
    } catch (err: any) {
      const status = err?.response?.status;
      const code = err?.response?.data?.error?.code;

      // Expected while gateway is initializing or already connected.
      if (status === 404 && (code === 'QR_NOT_AVAILABLE' || code === 'SESSION_NOT_FOUND')) {
        return;
      }

      // Avoid unhandled promise rejections spamming the console.
      return;
    }
  }

  useEffect(() => {
    let iv: any;
    if (step === 4 && session && apiKey) {
      fetchQr();
      iv = setInterval(fetchQr, 5000);
    }
    return () => iv && clearInterval(iv);
  }, [step, session?.sessionId, apiKey?.key]);

  async function saveWebhook() {
    if (!session) return;
    await api.post('/webhooks', { sessionId: session.sessionId, url: webhookUrl, events: ['message.received','message.status','session.status'] });
    next();
  }

  async function sendTestMessage() {
    if (!session || !apiKey) return;
    setSendingTest(true);
    try {
      await api.post('/messages/send', {
        to: '919000000000',
        text: 'Hello from SAK API!'
      }, { headers: { 'x-api-key': apiKey.key } });
      alert('Test message queued');
    } catch (e) {
      alert('Failed to send test message');
    } finally {
      setSendingTest(false);
    }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Get Started</h1>
      <p className="text-sm text-gray-600 mb-6">Onboard like Maytapi: API key → Session → QR → Webhook → Test.</p>

      {errorMsg ? (
        <div className="mb-6 border border-red-200 bg-red-50 text-red-700 rounded p-3 text-sm">
          {errorMsg}
        </div>
      ) : null}

      <div className="space-y-6">
        <div className={`border rounded p-4 ${step===2? 'border-blue-500':'border-gray-200'}`}>
          <h2 className="font-medium">Step 1: Create API Key & Session</h2>
          {apiKey && session ? (
            <div className="mt-2 space-y-1">
              <p className="text-sm">Key: <code className="bg-gray-100 px-1 py-0.5 rounded">{apiKey.key}</code></p>
              <p className="text-sm">Session: {session.name} ({session.status})</p>
              <button className="mt-3 btn" onClick={next}>Continue</button>
            </div>
          ) : (
            <button className="mt-3 btn" onClick={createApiKey}>Generate</button>
          )}
        </div>

        <div className={`border rounded p-4 ${step===3? 'border-blue-500':'border-gray-200'}`}>
          <h2 className="font-medium">Step 2: Confirm Session Status</h2>
          {session ? (
            <div className="mt-2">
              <p className="text-sm">Status: {session.status}{session.phoneNumber ? ` · ${session.phoneNumber}` : ''}</p>
              <button className="mt-3 btn" onClick={createSession}>Refresh & Continue</button>
            </div>
          ) : (
            <button className="mt-3 btn" onClick={createApiKey}>Create Session First</button>
          )}
        </div>

        <div className={`border rounded p-4 ${step===4? 'border-blue-500':'border-gray-200'}`}>
          <h2 className="font-medium">Step 3: Scan QR in WhatsApp</h2>
          <p className="text-sm text-gray-600">Open WhatsApp → Linked Devices → Link a device → Scan this QR.</p>
          <div className="mt-3">
            {qr ? (
              qr.startsWith('data:image') ? (
                <img src={qr} alt="QR" className="border rounded" />
              ) : (
                <pre className="bg-gray-100 p-2 rounded text-xs overflow-auto">{qr}</pre>
              )
            ) : (
              <p className="text-sm">Loading QR…</p>
            )}
          </div>
        </div>

        <div className={`border rounded p-4 ${step===5? 'border-blue-500':'border-gray-200'}`}>
          <h2 className="font-medium">Step 4: Set Webhook URL</h2>
          <div className="mt-2 flex gap-2">
            <input className="input flex-1" placeholder="https://yourapp.example.com/sak/webhook" value={webhookUrl} onChange={(e)=>setWebhookUrl(e.target.value)} />
            <button className="btn" onClick={saveWebhook} disabled={!webhookUrl || !session}>Save</button>
          </div>
        </div>

        <div className={`border rounded p-4 ${step===6? 'border-blue-500':'border-gray-200'}`}>
          <h2 className="font-medium">Step 5: Send Test Message</h2>
          <button className="btn" onClick={sendTestMessage} disabled={sendingTest || !session || !apiKey}>{sendingTest? 'Sending…':'Send Hello'}</button>
        </div>

        <div className="flex justify-between">
          <button className="btn-secondary" onClick={prev} disabled={step===1}>Back</button>
          <button className="btn" onClick={next} disabled={step===6}>Next</button>
        </div>
      </div>
    </div>
  );
}