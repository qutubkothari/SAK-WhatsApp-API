UPDATE sessions SET is_active = false, status = 'disconnected' WHERE session_id = 'b14c2ec9-ade4-4114-a1ed-35f753787fd2';
